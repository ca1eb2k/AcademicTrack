import tkinter as tk
from tkinter import *

root=Tk()
root.title("AcademicTracker - Homework Journal") # Changing the title of the window
root.iconbitmap("at_logo.ico")
root.geometry("1000x600")

L1 = Label(root, text="Subject 1", font=("Helvetica", "12"))
L1.grid(column=0,row=0)
L1 = Label(root, text="Subject 2", font=("Helvetica", "12"))
L1.grid(column=0,row=1)
L1 = Label(root, text="Subject 3", font=("Helvetica", "12"))
L1.grid(column=0,row=2)
L1 = Label(root, text="Subject 4", font=("Helvetica", "12"))
L1.grid(column=0,row=3)
L1 = Label(root, text="Subject 5", font=("Helvetica", "12"))
L1.grid(column=0,row=4)

L1 = Entry(root, width=150)
L1.grid(column=1,row=0)
L1 = Entry(root, width=150)
L1.grid(column=1,row=1)
L1 = Entry(root, width=150)
L1.grid(column=1,row=2)
L1 = Entry(root, width=150)
L1.grid(column=1,row=3)
L1 = Entry(root, width=150)
L1.grid(column=1,row=4)



root.mainloop()